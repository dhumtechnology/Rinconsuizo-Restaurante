<?php
  
  // include phpmailer class
  require_once 'PHPMailerAutoload.php';
  // creates object
  $mail = new PHPMailer(true); 
  
  if(isset($_POST['btn_send']))
  {
   $full_name  = strip_tags($_POST['full_name']);
   $email      = strip_tags($_POST['email']);
   $total      = strip_tags("500.00");
   $extras      = strip_tags("No solicitado");
   $cant_noche      = strip_tags("3");
   $start      = strip_tags("2021-07-17 12:00");
   $end      = strip_tags("2021-07-19 12:00");
   $tipo      = strip_tags("Matrimonial doble");
   $codigo      = strip_tags("T001- 00023");
   $subject    = "Detalles de la reserva Killa House";
   $text_message    = "";      
   
   
   // HTML email starts here
   
   $message  = "<html><body>";
   
   $message .= "<table width='100%' bgcolor='#e0e0e0' cellpadding='0' cellspacing='0' border='0'>";
   
   $message .= "<tr><td>";

   $message .= "<table align='center' width='100%' border='0' cellpadding='0' cellspacing='0' style='max-width:650px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;'>";
    
   $message .= "<thead>
      <tr height='80'>
       <th colspan='4' style='background-color:#f5f5f5; border-bottom:solid 1px #bdbdbd; font-family:Verdana, Geneva, sans-serif; color:#333; font-size:34px;' >
       <img src='http://killahotel.pe.hu/img/header.png' alt='Killa house' title='Killa house' style='height:auto; width:100%; max-width:100%;' />

       <hr />
        <p style='font-size:12px; font-family:Verdana, Geneva, sans-serif;'> Estimad@, muy buenas tardes. Con refencia a su solicitud de reservación le genero el siguiente código de reserva:</p>
       </th>
      </tr>
      </thead>";

   $message .= "</table>";




   $message .= "<table align='center' width='100%' border='1' cellpadding='0' cellspacing='0' style='max-width:400px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;'>";

   $message .= "<tbody>
      <tr align='center' height='50' style='font-family:Verdana, Geneva, sans-serif;'>
       <td colspan='2' style='background-color:#c2cfd8; text-align:center;'><a  style='color:black; text-decoration:none;'>Código de reserva</a></td>
       <td  colspan='2' style='background-color:white; text-align:center;'><a  style='color:black; text-decoration:none;'>".$codigo."</a></td>
      </tr>


      <tr>
       <td colspan='4' style='background-color:#7892a8; text-align:center;' >
        <p style='font-size:16px; color:white;'>DATOS DE LA RESERVA</p>
       </td>
      </tr>

      <tr>
       <td colspan='2' style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Titular de la reserva</p>
       </td>
       <td colspan='2' style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$full_name."</p>
       </td>
      </tr>

      <tr>
       <td colspan='2' style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Tipo de habitación</p>
       </td>
       <td colspan='2' style='background-color:white;'>
        <p style='font-size:11px;color:black;'> ".$tipo.",</p>
       </td>
      </tr>

      <tr>
       <td style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'> Check-in 1</p>
       </td>
       <td style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$start."</p>
       </td>
       <td style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Reingreso</p>
       </td>
       <td style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$start."</p>
       </td>
      </tr>

      <tr>
       <td style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'> Check-out 1</p>
       </td>
       <td style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$end."</p>
       </td>
       <td style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Check-out 2</p>
       </td>
       <td style='background-color:white;'>
        <p style='font-size:12px;color:black;'>".$end."</p>
       </td>
      </tr>

      <tr>
       <td colspan='2' style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Total de noches</p>
       </td>
       <td colspan='2' style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$cant_noche."</p>
       </td>
      </tr>

      <tr>
       <td colspan='2' style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Importe total</p>
       </td>
       <td colspan='2' style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$total."</p>
       </td>
      </tr>

      <tr>
       <td colspan='4' style='background-color:#7892a8; text-align:center;' >
        <p style='font-size:16px; color_white;'>SERVICIOS ADICIONALES</p>
       </td>
      </tr>

      <tr>
       <td colspan='2' style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Decoración especial</p>
       </td>
       <td colspan='2' style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$extras."</p>
       </td>
      </tr>

      <tr>
       <td colspan='2' style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Alimentos y bebidas</p>
       </td>
       <td colspan='2' style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$extras."</p>
       </td>
      </tr>

      <tr>
       <td colspan='2' style='background-color:#c2cfd8;'>
        <p style='font-size:12px;color:white;'>Recojo al aeropuerto</p>
       </td>
       <td colspan='2' style='background-color:white;'>
        <p style='font-size:12px;color:black;'> ".$extras."</p>
       </td>
      </tr>


     

      <tr>
       <td colspan='4' style='padding:15px;'>
        <p style='font-size:11px;'>El monto total de la reserva es de: S/.  ".$total." Nuevos soles</p>
        
        
       </td>
      </tr>


      </tbody>";
    
   $message .= "</table>";


   
   $message .= "<table align='center' width='100%' border='0' cellpadding='0' cellspacing='0' style='max-width:650px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;'>";

    
   $message .= "<tbody>
      
      <tr>
       <td colspan='4' style='padding:15px;'>
        
        <h2 style='font-size:25px; text-align:center;'>Protocolo de reserva </h2>
        </br>
        <p style='font-size:14px;'>La reserva generada tiene un periodo de validéz de 24 horas puesto que necesita ser confirmado por usted con un depósito a una de nuestras cuentas bancarias del 50% del monto total ( PEN  ".$total." )</p>

        
       </td>
      </tr>

      <tr>
       <td colspan='4' style='background-color:#7892a8; text-align:center;' >
        <p style='font-size:16px; color:white;'>CUENTAS BANCARIAS</p>
       </td>
      </tr>

      <tr>
       <td style='background-color:#9eb1c0; text-align:center;'>
        <p style='font-size:12px;color:white;'>Interbank</p>
       </td>
       <td style='background-color:#9eb1c0; text-align:center;'>
        <p style='font-size:12px;color:white;'> BCP</p>
       </td>
       <td style='background-color:#9eb1c0; text-align:center;'>
        <p style='font-size:12px;color:white;'> BBVA,</p>
       </td>
       <td style='background-color:#9eb1c0; text-align:center;'>
        <p style='font-size:12px;color:white;'> Scotiabank</p>
       </td>
      </tr>

      <tr>
       <td style='background-color:#c3ced7; text-align:center;'>
        <p style='font-size:12px;color:black; text-align:center;'>Número de cuenta</p>
       </td>
       <td style='background-color:#c3ced7; text-align:center;'>
        <p style='font-size:12px;color:black;'>Número de cuenta</p>
       </td>
       <td style='background-color:#c3ced7; text-align:center;'>
        <p style='font-size:12px;color:black;'>Número de cuenta</p>
       </td>
       <td style='background-color:#c3ced7; text-align:center;'>
        <p style='font-size:12px;color:black;'>Número de cuenta</p>
       </td>
      </tr>

      <tr>
       <td style='background-color:white; text-align:center;'>
        <p style='font-size:12px;color:black; text-align:center;'>426-306473481</p>
       </td>
       <td style='background-color:white; text-align:center;'>
        <p style='font-size:12px;color:black;'>426-3064734871</p>
       </td>
       <td style='background-color:white; text-align:center;'>
        <p style='font-size:12px;color:black;'>426-3064734871</p>
       </td>
       <td style='background-color:white; text-align:center;'>
        <p style='font-size:12px;color:black;'>426-3064734871</p>
       </td>
      </tr>


      <tr>
       <td style='background-color:#c3ced7; text-align:center;'>
        <p style='font-size:12px;color:black;'>CCI</p>
       </td>
       <td style='background-color:#c3ced7; text-align:center;'>
        <p style='font-size:12px;color:black;'>CCI</p>
       </td>
       <td style='background-color:#c3ced7; text-align:center;'>
        <p style='font-size:12px;color:black;'>CCI</p>
       </td>
       <td style='background-color:#c3ced7; text-align:center;'>
        <p style='font-size:12px;color:black;'>CCI</p>
       </td>
      </tr>

      <tr>
       <td style='background-color:white; text-align:center;'>
        <p style='font-size:9px;color:black;'>00342601306473487148</p>
       </td>
       <td style='background-color:white; text-align:center;'>
        <p style='font-size:9px;color:black;'>00342601306473487148</p>
       </td>
       <td style='background-color:white; text-align:center;'>
        <p style='font-size:9px;color:black;'>00342601306473487148</p>
       </td>
       <td style='background-color:white; text-align:center;'>
        <p style='font-size:9px;color:black;'>00342601306473487148</p>
       </td>
      </tr>

      <tr>
       <td colspan='2' style='background-color:white;'>
        <p style='font-size:12px;color:black;'>Si se deposita por transferencia por internet o a través de cajero automático no tiene comisión, si se deposita a través de una agencia de banco tiene una comisión dependiendo del banco.</p>
       </td>
       <td colspan='2' style='background-color:white;'>
        <img src='http://killahotel.pe.hu/img/pagos.png' alt='Killa house' title='Killa house' style='height:auto; width:100%; max-width:100%;' />
       </td>
       
      </tr>

      <tr>
       <td colspan='4' style='background-color:white;'>
        <p style='font-size:9px;color:black;'>Después de realizar el depósito por favor mándenos una copia del voucher emitido por el banco a esta misma dirección de correo electrónico info@killahotel.com A la espera de su información me despido de usted. Cualquier duda o interoogante estoy a su disposición. Gracias.</p>
        <h2 style='text-align:center;color:black;'>Gracias por confiar en Nosotros...!!!</h2>

        <p style='font-size:9px;color:black;'>Atte:</p>
        <p style='font-size:9px;color:black;'>@</p>
        <p style='font-size:9px;color:black;'>Departamento de reservas</p>
        <p style='font-size:9px;color:black;'>Whatsapp recepción: +51 970727893</p>
        <p style='font-size:9px;color:black;'>Whatsapp reservas: +51 984035544</p>
        <p style='font-size:9px;color:black;'>Av. Tullumayo #279 Cusco - Perú</p>
        <p style='font-size:9px;color:black;'>Teléfono: +51 - 84 - 234107</p>

        <img src='http://killahotel.pe.hu/img/loguitos.png' alt='Killa house' title='Killa house' style='height:auto; width:20%; max-width:20%;' />
        <p style='font-size:9px;color:black;'>Aviso importante. La información contenida en esta transmisión es confidencial y no puede ser usada por otras personas que su(s) destinatario(s). A la persona que lee este mensaje no siendo aquella a la cual va dirigido, se le comunica que el uso no autorizado o la retención, difusión, divulgación, distribución, copia o reproducción de este mensaje está prohibida y puede ser sancionado penalmente de acuerdo al Título IV del Código Penal peruano. Sí usted recibe este mensaje por error, por favor elimínelo y avise telefónicamente al remitente por cobro revertido ó e-mail. Considerando que no existe certidumbre que el presente mensaje no será modificado como resultado de su transmisión por correo electrónico. Killa House y su empresas vinculadas no serán responsables si el contenido del mismo ha sido modificado.</p>
       </td>
       
       
      </tr>
      
      </tbody>";
    
   $message .= "</table>";
   
   $message .= "</td></tr>";
   $message .= "</table>";
   
   $message .= "</body></html>";
   
   // HTML email ends here
   
   try
   {
    $mail->IsSMTP(); 
    $mail->isHTML(true);
    $mail->SMTPDebug  = 0;                     
    $mail->SMTPAuth   = true;                  
    $mail->SMTPSecure = "ssl";                 
    $mail->Host       = "smtp.gmail.com";      
    $mail->Port       = 465;             
    $mail->AddAddress($email);
    $mail->Username   ="nfychpas@gmail.com";  
    $mail->Password   ="Sistemas10";    

    $mail->SetFrom($email,'RESERVA KILLA HOUSE');
    $mail->AddReplyTo($email,"RESERVA KILLA HOUSE");
    $mail->Subject    = $subject;
    $mail->Body    = $message;
    $mail->AltBody    = $message;
     
    if($mail->Send())
    {
     
     $msg = "<div class='alert alert-success'>
       Hi,<br /> ".$full_name." mail was successfully sent to ".$email." go and check, cheers :)
       </div>";
     
    }
   }
   catch(phpmailerException $ex)
   {
    $msg = "<div class='alert alert-warning'>".$ex->errorMessage()."</div>";
   }
  } 
  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sending HTML eMail using PHPMailer in PHP</title>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="http://www.programacion.net" title='Programming Blog'>Programacion.net</a>
            <a class="navbar-brand" href="http://programacion.net/articulos/c">C</a>
            <a class="navbar-brand" href="http://programacion.net/articulos/php">PHP</a>
            <a class="navbar-brand" href="http://programacion.net/articulos/java">Java</a>
        </div>
    </div>
</div>


<div class="container">

 <div class="page-header">
     <h1>Send HTML eMails using PHPMailer in PHP</h1>
    </div>
     
    <div class="email-form">
    
     <?php
  if(isset($msg))
  {
   echo $msg;
  }
  ?>
        
     <form method="post" class="form-control-static">
        
            <div class="form-group">
                <input class="form-control" type="text" name="full_name" placeholder="Full Name" />
            </div>
            
            <div class="form-group">
                <input class="form-control" type="text" name="email" placeholder="Your Mail" />
            </div>
            
            <div class="form-group">
                <button class="btn btn-success" type="submit" name="btn_send">
                <span class="glyphicon glyphicon-envelope"></span> Send Mail
                </button>
            </div>
        
     </form>
    </div>    
</div>

</body>

</html>